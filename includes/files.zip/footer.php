<!--============================
    FOOTER START
=============================-->
<footer
  class="mt_120 xs_mt_100 pt_75"
  style="background: url(assets/images/footer_bg.jpg)"
>
  <div class="container">
    <div class="row">
      <div class="col-12 wow fadeInUp">
        <ul class="footer_top">
          <li>
            <div class="icon">
              <img
                src="assets/images/call_icon_blue.svg"
                alt="Call"
                class="img-fluid"
              />
            </div>
            <div class="text">
              <span>Need Junk Removal!</span>
              <a href="tel:+14078154926">+1 407.815.4926</a>
            </div>
          </li>
          <li>
            <div class="icon">
              <img
                src="assets/images/mail_icon_blue.svg"
                alt="Mail"
                class="img-fluid"
              />
            </div>
            <div class="text">
              <span>Send Email</span>
              <a href="mailto:hello@haulinjunkies.com">hello@haulinjunkies.com</a>
            </div>
          </li>
          <li>
            <div class="icon">
              <img
                src="assets/images/location_icon_blue.svg"
                alt="Location"
                class="img-fluid"
              />
            </div>
            <div class="text">
              <span>Our Location</span>
              <p>Maitland</p>
            </div>
          </li>
        </ul>
      </div>
    </div>
    <div class="row justify-content-between">
      <div class="col-md-6 col-lg-3 col-xl-3 wow fadeInUp">
        <div class="footer_info">
          <a href="index.html" class="footer_logo">
            <img
              src="assets/images/logo.png"
              alt="Haulin Junkies - Junk Removal Orlando"
              class="img-fluid"
            />
          </a>
          <p>
            Haulin Junkies is your trusted local partner for fast, affordable junk removal in Orlando and Central Florida. Residential, commercial, and specialty hauling services.
          </p>
          <ul class="footer_social d-flex flex-wrap">
            <li>
              <a href="#"><i class="fab fa-facebook-f"></i></a>
            </li>
            <li>
              <a href="#"><i class="fab fa-linkedin-in"></i></a>
            </li>
            <li>
              <a href="#"><i class="fab fa-twitter"></i></a>
            </li>
          </ul>
        </div>
      </div>
      <div class="col-md-6 col-sm-6 col-lg-3 col-xl-2 wow fadeInUp">
        <div class="footer_link">
          <h3>Services</h3>
          <ul>
            <li><a href="residential.html">Residential Junk Removal</a></li>
            <li><a href="commercial.html">Commercial Junk Removal</a></li>
            <li><a href="apartment_cleanouts.html">Apartment Cleanouts</a></li>
            <li><a href="concrete-removal.html">Construction Debris</a></li>
            <li><a href="appliance-removal.html">Appliance Removal</a></li>
          </ul>
        </div>
      </div>
      <div class="col-md-6 col-sm-6 col-lg-2 col-xl-2 wow fadeInUp">
        <div class="footer_link footer_link_padding">
          <h3>Quick links</h3>
          <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="contact_us.html">Contact</a></li>
             <li><a class="book_now_btn" href="#" onclick="openBookingModal(); return false;">book now</a></li>
          </ul>
        </div>
      </div>
      <div class="col-md-6 col-sm-12 col-lg-4 col-xl-3 wow fadeInUp">
        <div class="footer_time">
          <h3>Working Hours:</h3>
          <ul>
            <li><span>Mon - Fri</span> 7:00 AM - 6:00 PM</li>
            <li><span>Sat </span> 10 AM - 4 PM</li>
            <li><span>Sun </span> Closed </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <div class="footer_copyright">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="footer_copyright_text d-flex flex-wrap">
            <p>© 2025 <b>Haulin Junkies</b>. All Rights Reserved.</p>
            <ul class="d-flex flex-wrap">
            <!--
              <li><a href="#">Setting & Privacy </a></li>
              <li><a href="#">FAQ</a></li>
              <li><a href="#">Support</a></li>
              -->
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>

<script src="//code.tidio.co/v1blsnfffdz5pth2ee9ebgnfw9e0b3rq.js" async></script>
<!--============================
    FOOTER END
=============================-->
